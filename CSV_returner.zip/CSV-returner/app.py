import os
import subprocess
import pandas as pd
import sys
import logging

def strip_units(value):
    if isinstance(value, str):
        value = value.replace('²', '')
        value = ''.join(filter(lambda x: x.isdigit() or x == '.' or x == '-', value))
    try:
        return f"{float(value):.6f}"
    except ValueError:
        return value

def process_csv_file(file_path):
    df = pd.read_csv(file_path, encoding='ISO-8859-1')

    for column in df.columns:
        if 'Sample time' not in column:
            df[column] = df[column].apply(strip_units)

    output_path = file_path[:-4] + "_final.csv"
    print(f"Saving processed file to: {output_path}")
    
    df.to_csv(output_path, index=False, float_format='%.6f')
    
    os.remove(file_path)
    print(f"Deleted original file: {file_path}")
    return output_path

def process_video_file(video_file_path):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    gpmf_parser_path = os.path.join(script_dir, 'C-code', 'csv_extractor', 'gpmf-parser')
    
    if not os.path.exists(gpmf_parser_path):
        logging.error(f"The path {gpmf_parser_path} does not exist.")
        return False
    
    try:
        subprocess.run([gpmf_parser_path, video_file_path], check=True)
        logging.debug("GPMF Parser executed successfully")
        return True
    except subprocess.CalledProcessError as e:
        logging.error(f"Error executing GPMF Parser: {e}")
        return False

def main():
    if len(sys.argv) != 2:
        print("Usage: python app.py <video_file_path>")
        sys.exit(1)

    video_file_path = sys.argv[1]

    if not process_video_file(video_file_path):
        print("Failed to process video.")
        sys.exit(1)

    csv_files = [f"{video_file_path}_ACCL_sample.csv", f"{video_file_path}_GYRO_sample.csv", f"{video_file_path}_GPS9_sample.csv"]

    for csv_file in csv_files:
        process_csv_file(csv_file)

if __name__ == "__main__":
    main()

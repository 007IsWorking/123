# GPMF-parser Authors List

##### Please add entries to the bottom of the list in the following format
* `@GitHub UserName (Required) - [Name and/or Organization](link)`

# Authors
* @dnewman-gpsw - [GoPro, Inc.] (https://github.com/GoPro/gpmf-parser)
* @tcheema-gpsw - [GoPro, Inc.] (https://github.com/GoPro/gpmf-parser)

